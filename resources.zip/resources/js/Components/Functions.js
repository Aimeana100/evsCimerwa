import React from 'react'

const Functions = () => {
  return (
    <div>Functions</div>
  )
}

export default Functions