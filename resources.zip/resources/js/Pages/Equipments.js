import Sidebar from "@/AppComponents/Sidebar";
import Authenticated from "@/Layouts/Authenticated";
import { Head } from "@inertiajs/inertia-react";
import React from "react";

export default function Equipments(props) {
    return (
        <>
        
            <Sidebar />
            <div className="" >
                Equipments
            </div>

          
        </>
    );
}
